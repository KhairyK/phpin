<!DOCTYPE html>
<html lang="id-ID">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Learning Frontend || PHPin</title>
  <link rel="icon" href="https://phpin.infinityfreeapp.com/phpin_logo.png" type="image/png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/simple-icons-font@latest/font/simple-icons.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="/resource/style.css">
</head>
<body>
  <div class="position">
    <div class="container-box-primary">
      <h2 class="rainbow-font-header">HTML</h2>
      <blockquote class="text-md">
        Apa Itu HTML? HTML(HyperText Markup Language) Adalah Sebuah Bahasa Markup Yang Dibuat Oleh W3C. HTML Berguna Sebagai <strong>Kerangka Dasar Kepada Website</strong> Agar Hasil Konten Nya Akan Keluar Dengan HTML. HTML Bisa Digabung Dengan CSS Hanya Cara Menambahkan Tag <code>&lt;style&gt;</code> Dan Juga HTML Bisa Digabung Dengan JS Dengan Cara Menambahkan Tag <code>&lt;script&gt;</code>. Selain Itu HTML Bisa Diintegrasikan Dengan Bahasa Pemograman Server yaitu <strong>PHP</strong>. Cara Nya Hanya Menambahkan Tag <code>&lt;?php ?&gt;</code>. PHP Membutuhkan Tag Buka Dan Tutup.
      </blockquote>
      <hr class="hr-gradient">
      <h3 class="text-md">Contoh Kode HTML(All in One)</h3>
      <div class="example-code">
        Heading<br>
        <code>
          &lt;h1&gt;
          &lt;h2&gt;
          &lt;h3&gt;
          &lt;h4&gt;
          &lt;h5&gt;
          &lt;h6&gt;
        </code><br><br>
        Struktur & Metadata<br>
        <code>
          &lt;html&gt;
          &lt;meta&gt;
          &lt;link&gt;
          &lt;title&gt;
          &lt;base&gt;
          &lt;style&gt;
        </code><br><br>
        Struktur Konten<br>
        <code>
          &lt;body&gt;
          &lt;header&gt;
          &lt;nav&gt;
          &lt;section&gt;
          &lt;articke&gt;
          &lt;aside&gt;
          &lt;footer&gt;
          &lt;main&gt;
        </code><br><br>
        Konten Teks & Grup<br>
        <code>
          Heading
          &lt;p&gt;
          &lt;hr&gt;
          &lt;pre&gt;
          &lt;blockquote&gt;
          &lt;ol&gt;
          &lt;ul&gt;
          &lt;dl&gt;
          &lt;dt&gt;
          &lt;dd&gt;
          &lt;figure&gt;
          &lt;figcaption&gt;
        </code><br><br>
        Teks Kecil/Spesifik<br>
        <code>
          &lt;a&gt;
          &lt;em&gt;
          &lt;strong&gt;
          &lt;small&gt;
          &lt;s&gt;
          &lt;cite&gt;
          &lt;q&gt;
          &lt;dfn&gt;
          &lt;abbr&gt;
          &lt;ruby&gt;
          &lt;rt&gt;
          &lt;rp&gt;
          &lt;data&gt;
          &lt;time&gt;
          &lt;code&gt;
          &lt;samp&gt;
          &lt;var&gt;
          &lt;kbd&gt;
          &lt;sub&gt;
          &lt;sup&gt;
          &lt;i&gt;
          &lt;b&gt;
          &lt;u&gt;
          &lt;mark&gt;
          &lt;span&gt;
          &lt;br&gt;
          &lt;wbr&gt;
        </code><br><br>
        Gambar & Multimedia<br>
        <code>
          &lt;img&gt;
          &lt;iframe&gt;
          &lt;embed&gt;
          &lt;object&gt;
          &lt;param&gt;
          &lt;vidio&gt;
          &lt;audio&gt;
          &lt;source&gt;
          &lt;track&gt;
        </code><br><br>
        Scripting<br>
        <code>
          &lt;script&gt;
          &lt;noscript&gt;
          &lt;canvas&gt;
          &lt;template&gt;
          &lt;slot&gt;
        </code><br><br>
        Tanda Edit/Ubah<br>
        <code>
          &lt;ins&gt;
          &lt;del&gt;
        </code><br><br>
        Tabel<br>
        <code>
          &lt;table&gt;
          &lt;caption&gt;
          &lt;colgroup&gt;
          &lt;col&gt;
          &lt;thead&gt;
          &lt;tbody&gt;
          &lt;tfoot&gt;
          &lt;tr&gt;
          &lt;th&gt;
          &lt;td&gt;
        </code><br><br>
        Formulir<br>
        <code>
          &lt;form&gt;
          &lt;label&gt;
          &lt;input&gt;
          &lt;button&gt;
          &lt;select&gt;
          &lt;datalist&gt;
          &lt;optgroup&gt;
          &lt;option&gt;
          &lt;textarea&gt;
          &lt;output&gt;
          &lt;progress&gt;
          &lt;meter&gt;
          &lt;fieldset&gt;
          &lt;legend&gt;
        </code><br><br>
        Interaktif<br>
        <code>
          &lt;detail&gt;
          &lt;summary&gt;
          &lt;dialog&gt;
        </code><br><wbr>
        <p>Total Ada ±110 Tag Di HTML</p>
        <p>Dan Ada Beberapa Yang Sudah <a class="" href="#obsolete">Dihapus</a> Dan <a href="#deprecated">Not-Recomended</a></p>
        <button class="btn btn-primary text-md" onclick="window.location.href='#penjelasan';">Penjelasan Kode HTML</button>
      </div>
      <br>
      <hr class="hr-gradient">
      <i class="si si-html5 icon"></i>
    </div> 
    
    <div class="container-box-primary">
      <h2 class="rainbow-font-header">CSS</h2>
      <article class="text-md">Apa Itu CSS? CSS(Casading Style Sheet) Adalah Sebuah Bahasa Style Untuk Mengatur Gaya HTML. Singkat Nya HTML Itu Kerangka, CSS Itu Gaya Kulit, Tangan, Kaki, Dll.</article>
      <hr class="hr-gradient">
      <button class="btn btn-primary text-md" onclick="window.location.href = 'all-css-code.php';">Contoh Kode CSS(All in One)</button>
      <br>
      <hr class="hr-gradient">
      <i class="fab fa-css3-alt icon"></i>
      </div>
    
    <div class="container-logo-profile">
      <p class="text-md text-bold-logo-profile">Powered By</p>
      <img src="https://phpin.infinityfreeapp.com/phpin_logo.png" class="profile-logo" alt="PHPin Logo" /><br>
      <p class="text-md">By Sholehuddin Khairy</p>
    </div>
  </div>
  
<script src="https://www.google.com/recaptcha/api.js?render=6LeHYNArAAAAAO4qZOW5m3di-fVualkc9RQLzn76"></script>
<script>
  grecaptcha.ready(function() {
    grecaptcha.execute("6LeHYNArAAAAAO4qZOW5m3di-fVualkc9RQLzn76", {action: "background_check"})
      .then(function(token) {
        fetch("verify.php", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: "g-recaptcha-response=" + encodeURIComponent(token)
        });
      });
  });
</script>
</body>
</html>